# This is a sample Python script.
import networkx as nx
import numpy as np
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from collections import Counter
import json
import os


# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

def generate_snapshots():
    file_path = 'C:\\Users\\97037\\PycharmProjects\\view_prac\\thiers_2012.csv'

    # 设置窗口宽度和步长
    window_width = 60  # 每帧时间窗口为60分钟
    step_size = 6  # 前后两帧有54分钟重叠，即每次移动6分钟

    snapshots = []

    def getSection():
        with open(file_path, 'r') as file:
            lines = [line.strip().split() for line in file.readlines()]
            end = int(lines[-1][0]) / 60
            current_start = int(lines[0][0]) / 60
        # print(current_start,end)
        return current_start, end, lines

    def getEdge(snapShot):
        edge_weights = {}
        for snap in snapShot:
            edge = (snap[1], snap[2])
            if edge in edge_weights:
                edge_weights[edge] += 1
            else:
                edge_weights[edge] = 1
        return edge_weights

    time_start, time_end, lines = getSection()
    vertexs = {}
    for line in lines:
        vertexs[line[1]] = line[3]
        vertexs[line[2]] = line[4]
    while time_start < time_end:
        res = list(filter(lambda x: time_start + window_width > int(x[0]) / 60 >= time_start,
                          lines))
        res = getEdge(res)
        snapshots.append(res)
        time_start += step_size
    return snapshots, vertexs


def plotSnapshot(snapshot):
    G = nx.DiGraph()
    for vertex in vertexs.keys():
        G.add_node(vertex)
    for edge, weight in snapshot.items():
        G.add_edge(edge[0], edge[1], weight=weight)
    # 计算每个节点的度数（出度和入度）
    degree_sequence = [d for n, d in G.degree()]

    # 使用 Counter 计算度数分布
    degree_count = Counter(degree_sequence)

    # 生成邻接矩阵，使用权重
    adj_matrix = nx.adjacency_matrix(G, weight='weight')
    adj_matrix_arr = adj_matrix.toarray()
    res = adj_matrix_arr[0]
    # 遍历每一行
    for row in adj_matrix_arr[1:]:
        res = res + row
    return res, degree_count


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    file_path = 'data.json'
    # if not os.path.exists(file_path):
    snapshots, vertexs = generate_snapshots()
    # print(snapshots)
    vectors = []
    degree_counts = []
    for snapshot in snapshots:
        vector, degree_count = plotSnapshot(snapshot)
        vectors.append(vector)
        degree_counts.append(degree_count)
    # 转换为高维向量数组
    vectors = np.array(vectors)
    # print(degree_counts)
    # print(snapshots)
    snapshots = [[{"from": k[0], "to": k[1], "weight": v} for k, v in snapshot.items()] for snapshot in snapshots]

    with open('C:\\Users\\97037\\Desktop\\code\\Freshman-Training\\snapshots.json', 'w') as json_file:
        json.dump(snapshots, json_file, indent=4)

    dict_list = [dict(counter) for counter in degree_counts]
    # 将字典列表转换为 JSON 格式并保存
    with open('C:\\Users\\97037\\Desktop\\code\\Freshman-Training\\degree_counts.json', 'w') as json_file:
        json.dump(dict_list, json_file, indent=4)

    with open('C:\\Users\\97037\\Desktop\\code\\Freshman-Training\\vertexs.json', 'w') as json_file:
        json.dump(vertexs, json_file, indent=4)
    # else:
    #     with open('data.json', 'r') as file:
    #         vectors = json.load(file)
    #         # 将列表转换回 NumPy 数组
    #         vectors = np.array(vectors)

    # 使用PCA进行降维
    pca = PCA(n_components=2)
    reduced_data_pca = pca.fit_transform(vectors)

    # 将降维后的数据保存为JSON格式
    with open('C:\\Users\\97037\\Desktop\\code\\Freshman-Training\\reduced_data_pca.json', 'w') as json_file:
        json.dump(reduced_data_pca.tolist(), json_file, indent=4)

    # 使用t-SNE进行降维
    tsne = TSNE(n_components=2)
    reduced_data_tsne = tsne.fit_transform(vectors)

    # with open('reduced_data_tsne.json', 'w') as json_file:
    #     json.dump(reduced_data_tsne.tolist(), json_file, indent=4)

    # 可视化降维结果
    plt.figure(figsize=(14, 6))

    plt.subplot(1, 2, 1)
    plt.scatter(reduced_data_pca[:, 0], reduced_data_pca[:, 1], c='blue', label='PCA')
    plt.title('PCA')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.scatter(reduced_data_tsne[:, 0], reduced_data_tsne[:, 1], c='red', label='t-SNE')
    plt.title('t-SNE')
    plt.legend()

    plt.show()
